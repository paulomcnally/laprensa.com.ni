<?php

class DMPPanelSLPTag               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Tagalong');
    }
}
