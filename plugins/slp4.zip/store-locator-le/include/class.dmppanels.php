<?php

class DMPPanelSLPMain               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP');
    }
}
class DMPPanelSLPMapLocation        extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Location');
    }
}
class DMPPanelSLPMapSettings        extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Map Settings');
    }
}
class DMPPanelSLPManageLocations    extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Manage Locations');
    }
}

