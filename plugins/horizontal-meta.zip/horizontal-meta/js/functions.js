function hm_empty(val) {
	if(val=='' || val == undefined || val == null || val == 0 || val == false) {
		return true;
	} else {
		return false;
	}
}