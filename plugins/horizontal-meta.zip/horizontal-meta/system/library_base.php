<?php

if(! class_exists("hmeta_library_base")) {

	class hmeta_library_base extends hmeta_loader_base {

		function __construct() { parent::__construct(); }


	}
}