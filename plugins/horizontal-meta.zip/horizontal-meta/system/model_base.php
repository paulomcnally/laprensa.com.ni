<?php

if(!class_exists("hmeta_model_base")) {

	class hmeta_model_base extends hmeta_loader_base {

	}
}