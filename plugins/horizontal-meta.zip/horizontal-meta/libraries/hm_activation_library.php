<?php

class hm_activation_library extends hmeta_library_base {

	function is_activated() {
		return true;
	}

}