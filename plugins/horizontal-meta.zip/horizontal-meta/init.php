<?php

/*
 * Include specific intialise functions for plugin.
 * This includes things like registering post types, taxonomies etc...
 * Do this only if you are not using the MVC functions of this plugin
 */

