<?php

/**
 * The Debug My Plugin specialized class.
 *
 * @package DebugMyPlugin\SLP-ER
 * @author Lance Cleveland <lance@charlestonsw.com>
 * @copyright 2013 Charleston Software Associates, LLC
 *
 */
class DMPPanelSLPER               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP ER');
    }
}
