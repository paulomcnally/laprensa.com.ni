<?php

class DMPPanelSLPPro               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP PRO');
    }
}
