If you are a site administrator and have been accidentally locked out, please enter your email in the box below and click "Send". If the email address you enter belongs to a known site administrator or someone set to receive Wordfence alerts, we will send you an email to help you regain access. <a href="http://www.wordfence.com/docs/frequently-asked-questions/#3" target="_blank">Please read our FAQ if this does not work.</a>
<br /><br />
<form method="POST" action="<?php echo wfUtils::getSiteBaseURL(); ?>?_wfsf=unlockEmail">
<input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wf-form'); ?>" />
<input type="text" size="50" name="email" value="" maxlength="255" />&nbsp;<input type="submit" name="s" value="Send me an unlock email" />
</form>
<br /><br />
