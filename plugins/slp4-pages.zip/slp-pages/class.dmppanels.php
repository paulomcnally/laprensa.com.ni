<?php

class DMPPanelSLPPages               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Pages');
    }
}
