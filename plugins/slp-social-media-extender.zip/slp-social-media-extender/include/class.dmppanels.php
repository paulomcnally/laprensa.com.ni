<?php

/**
 * The Debug My Plugin specialized class.
 *
 * @package DebugMyPlugin\SocialMediaExtender
 * @author De B.A.A.T. <slp-sme@de-baat.nl>
 * @copyright 2014 Charleston Software Associates, LLC - De B.A.A.T.
 *
 */
class DMPPanelSLPSocialMediaExtender               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP Social Media Extender');
    }
}
