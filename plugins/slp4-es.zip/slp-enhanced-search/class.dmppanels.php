<?php

class DMPPanelSLPES               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP ES');
    }
}
