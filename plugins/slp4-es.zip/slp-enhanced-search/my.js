/*****************************************************************
 * file: my.js
 *
 *****************************************************************/

jQuery(document).ready(function($) {
        $('#map_sidebar').bind('contentchanged',function() {
            // alert('enhanced search is active');
        });
});

