<?php

class DMPPanelSLPEXContacts               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP SE C');
    }
}
