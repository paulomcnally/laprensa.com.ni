<?php

class DMPPanelSLPEM               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP EM');
    }
}
