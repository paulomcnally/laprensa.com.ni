<?php

/**
 * The Debug My Plugin specialized class.
 *
 * @package DebugMyPlugin\UserManagedLocations
 * @author De B.A.A.T. <slp-uml@de-baat.nl>
 * @copyright 2014 Charleston Software Associates, LLC - De B.A.A.T.
 *
 */
class DMPPanelSLPUserManagedLocations               extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('SLP User Managed Locations');
    }
}
