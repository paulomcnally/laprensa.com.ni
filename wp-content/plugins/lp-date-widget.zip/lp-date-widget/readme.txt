=== lp-date-widget ===
Contributors: David Menache, Shawn Crowe
Tags: Doap, DevOps and Platforms
Donate link: http://doap.com/donate
Requires at least: 3.9.1
Tested up to: 3.9.1
License: http://doap.com/tos
License URI: http://doap.com/tos

Spanish language date tag generator

== Description ==
Puts the date into the header of the page of the La Prensa Noticias theme. 

== Installation ==
Enable it in the La Prensa site.

== Frequently Asked Questions ==
no faq yet.  ask shawn or dave for help.

